package com.example.projeadi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBar1, seekBar2;
    TextView tvS1, tvS2;
    Button btnGec;

    int s1 = 0;
    int s2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar1 = findViewById(R.id.seekBar1);
        seekBar2 = findViewById(R.id.seekBar2);
        tvS1 = findViewById(R.id.tvS1);
        tvS2 = findViewById(R.id.tvS2);
        btnGec = findViewById(R.id.btnGec);

        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                s1 = progress;
                tvS1.setText("S1: " + s1);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                s2 = progress;
                tvS2.setText("S2: " + s2);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        btnGec.setOnClickListener(v -> {
            int min = Math.min(s1, s2);
            int max = Math.max(s1, s2);

            Random random = new Random();
            int uretilenSayi = random.nextInt(max - min + 1) + min;

            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("randomNumber", uretilenSayi);
            startActivity(intent);
        });
    }
}