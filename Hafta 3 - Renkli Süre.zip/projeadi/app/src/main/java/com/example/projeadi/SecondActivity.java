package com.example.projeadi;

import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class SecondActivity extends AppCompatActivity {

    TextView tvRandomNumber, tvKalanSure;
    LinearLayout secondLayout;

    int gelenSayi;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvRandomNumber = findViewById(R.id.tvRandomNumber);
        tvKalanSure = findViewById(R.id.tvKalanSure);
        secondLayout = findViewById(R.id.secondLayout);

        gelenSayi = getIntent().getIntExtra("randomNumber", 0);

        tvRandomNumber.setText("Üretilen Sayı: " + gelenSayi);
        tvKalanSure.setText("Kalan Süre: " + gelenSayi);

        new CountDownTimer(gelenSayi * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int kalanSaniye = (int) (millisUntilFinished / 1000);

                tvKalanSure.setText("Kalan Süre: " + kalanSaniye);

                int r = random.nextInt(256);
                int g = random.nextInt(256);
                int b = random.nextInt(256);

                secondLayout.setBackgroundColor(Color.rgb(r, g, b));
            }

            @Override
            public void onFinish() {
                tvKalanSure.setText("Kalan Süre: 0");
                Toast.makeText(SecondActivity.this, "uyg bitmişyit", Toast.LENGTH_SHORT).show();
            }
        }.start();
    }
}