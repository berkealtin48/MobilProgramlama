package com.example.sehirplaka;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ListView listIller, listPlakalar;
    Button btnPlakaUret;

    String[] iller = {
            "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya",
            "Ankara", "Antalya", "Artvin", "Aydın", "Balıkesir",
            "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur",
            "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli",
            "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum",
            "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari",
            "Hatay", "Isparta", "Mersin", "İstanbul", "İzmir",
            "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir",
            "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa",
            "Kahramanmaraş", "Mardin", "Muğla", "Muş", "Nevşehir",
            "Niğde", "Ordu", "Rize", "Sakarya", "Samsun",
            "Siirt", "Sinop", "Sivas", "Tekirdağ", "Tokat",
            "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van",
            "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman",
            "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan",
            "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye",
            "Düzce"
    };

    ArrayList<Integer> karisikPlakalar;
    ArrayAdapter<String> ilAdapter;
    ArrayAdapter<Integer> plakaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listIller = findViewById(R.id.listIller);
        listPlakalar = findViewById(R.id.listPlakalar);
        btnPlakaUret = findViewById(R.id.btnPlakaUret);

        ilAdapter = new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                iller
        );
        listIller.setAdapter(ilAdapter);

        karisikPlakalar = new ArrayList<>();
        plakalariKaristir();

        listIller.setOnItemClickListener((parent, view, position, id) -> {
            String secilenIl = iller[position];
            int gercekPlaka = position + 1;
            int gosterilenPlaka = karisikPlakalar.get(position);

            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("ilAdi", secilenIl);
            intent.putExtra("gercekPlaka", gercekPlaka);
            intent.putExtra("gosterilenPlaka", gosterilenPlaka);
            startActivity(intent);
        });

        btnPlakaUret.setOnClickListener(v -> {
            plakalariKaristir();
        });
    }

    private void plakalariKaristir() {
        karisikPlakalar.clear();

        for (int i = 1; i <= 81; i++) {
            karisikPlakalar.add(i);
        }

        Collections.shuffle(karisikPlakalar);

        plakaAdapter = new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                karisikPlakalar
        );

        listPlakalar.setAdapter(plakaAdapter);
    }
}