package com.example.sehirplaka;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView txtIlAdi, txtGosterilenPlaka, txtGercekPlaka, txtSonuc;
    Button btnGeriDon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtIlAdi = findViewById(R.id.txtIlAdi);
        txtGosterilenPlaka = findViewById(R.id.txtGosterilenPlaka);
        txtGercekPlaka = findViewById(R.id.txtGercekPlaka);
        txtSonuc = findViewById(R.id.txtSonuc);
        btnGeriDon = findViewById(R.id.btnGeriDon);

        String ilAdi = getIntent().getStringExtra("ilAdi");
        int gercekPlaka = getIntent().getIntExtra("gercekPlaka", 0);
        int gosterilenPlaka = getIntent().getIntExtra("gosterilenPlaka", 0);

        txtIlAdi.setText("Şehir: " + ilAdi);
        txtGosterilenPlaka.setText("Gösterilen Plaka: " + gosterilenPlaka);
        txtGercekPlaka.setText("Gerçek Plaka: " + gercekPlaka);

        if (gercekPlaka == gosterilenPlaka) {
            txtSonuc.setText("Sonuç: Doğru Eşleşme");
        } else {
            txtSonuc.setText("Sonuç: Yanlış Eşleşme");
        }

        btnGeriDon.setOnClickListener(v -> finish());
    }
}